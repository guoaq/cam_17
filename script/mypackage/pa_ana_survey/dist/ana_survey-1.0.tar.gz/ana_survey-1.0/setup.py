from setuptools import setup

setup(name='ana_survey',
      version='1.0',
      description='Package to analysis the survey data for BELLEII B field measurement campaign',
      url='',
      author='guoaq',
      author_email='guoaq@foxmail.com',
      license='DESY',
      packages=['ana_survey'],
      zip_safe=False)
